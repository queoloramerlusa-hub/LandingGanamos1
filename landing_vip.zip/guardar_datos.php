<?php
// Intentar cargar el núcleo de WordPress
// Esto asume que subiste la carpeta directamente a public_html (ej: tusitio.com/vip/)
$wp_load = dirname(__FILE__) . '/../wp-load.php';

if (!file_exists($wp_load)) {
    // Segunda alternativa para buscar wp-load.php
    $wp_load = $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

if (!file_exists($wp_load)) {
    die(json_encode(['error' => 'No se pudo conectar con WordPress. Verifica que la carpeta esté en el lugar correcto.']));
}

require_once($wp_load);
header('Content-Type: application/json');

// Obtener los datos enviados desde JavaScript
$data = json_decode(file_get_contents('php://input'), true);

$nombre = isset($data['nombre']) ? sanitize_text_field($data['nombre']) : '';
$telefono = isset($data['telefono']) ? sanitize_text_field($data['telefono']) : '';

if (empty($nombre) || empty($telefono)) {
    echo json_encode(['error' => 'Faltan datos']);
    exit;
}

// Guardar en WordPress como un "Borrador" (Draft) en las Entradas (Posts)
// Al ser borrador, nadie lo verá en tu blog público, pero tú lo verás en tu panel de WP.
$post_data = array(
    'post_title'    => 'Lead Ruleta: ' . $nombre . ' - ' . $telefono,
    'post_content'  => "<strong>Nombre:</strong> {$nombre} <br><strong>Teléfono:</strong> {$telefono} <br><strong>Fecha:</strong> " . current_time('mysql'),
    'post_status'   => 'draft', // Importante: Borrador para que sea privado
    'post_type'     => 'post',
);

$post_id = wp_insert_post($post_data);

if ($post_id) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'No se pudo guardar el lead en WordPress.']);
}
?>
